-- AlterTable
ALTER TABLE `note` MODIFY `content` TEXT NOT NULL;
