-- AlterTable
ALTER TABLE `category` ALTER COLUMN `parentId` DROP DEFAULT;
